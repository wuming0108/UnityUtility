﻿using GameFramework;
using GameFramework.Resource;
using System;
using System.IO;
using UnityEngine;
using UnityGameFramework.Runtime;

namespace UnityGameFrameworkExtend.IL
{
    /// <summary>
    ///  
    /// </summary>
    public class ILComponent : GameFrameworkComponent
    {
        private class LoadILRuntimeDllUserData
        {
            public string FileName;
            public OnLoadAssetSuccess OnSuccess;
            public OnLoadAssetFailure OnFailure;
        }

        private const string DLL_PATH = "";
        private const string PDB_PATH = "";

        private byte[] m_PDBData;
        private byte[] m_DLLData;

        public delegate void OnLoadAssetSuccess();
        public delegate void OnLoadAssetFailure(LoadResourceStatus status, string errorMessage);


        private IScriptInterpreter m_ScriptInterpreter;
        private LoadILRuntimeDllUserData m_LoadDllData;

        public  IScriptInterpreter ScriptInterpreter
        {
            get
            {
                return m_ScriptInterpreter;
            }
        }
  
#region MonoBehaviour

        private void Start()
        {
            
        }

        private void OnDestroy()
        {
           
        }

#endregion MonoBehaviour


        public void Init(OnLoadAssetSuccess success, OnLoadAssetFailure fail = null)
        {
#if UNITY_EDITOR
            m_ScriptInterpreter = new MonoInterpreter();
#else
            m_ScriptInterpreter = new ILInterpreter();
#endif
            m_LoadDllData = new LoadILRuntimeDllUserData { OnSuccess = success, OnFailure = fail };
            LoadFile(DLL_PATH);
            LoadFile(PDB_PATH);

        }


        /// <summary>
        /// 加载 DLL 脚本文件。
        /// </summary>
        /// <param name="assetPath">DLL 脚本的资源路径。</param> 

        private void LoadFile(string assetPath)
        {
            // Load lua script from AssetBundle.
            var innerCallbacks = new LoadAssetCallbacks(
                loadAssetSuccessCallback: OnLoadSuccess,
                loadAssetFailureCallback: OnLoadFailure);
            GameEntry.GetComponent<ResourceComponent>().LoadAsset(assetPath, innerCallbacks, assetPath);
        }

        private void OnLoadFailure(string assetName, LoadResourceStatus status, string errorMessage, object userData)
        { 
            if (null == m_LoadDllData || null == m_LoadDllData.OnFailure)
                return;

            m_LoadDllData.OnFailure( status, errorMessage);

            m_LoadDllData = null;
            m_DLLData = null;
            m_PDBData = null;
        }

        private void OnLoadSuccess(string assetName, object asset, float duration, object userData)
        {
            string path = (string)userData;
            if(path == DLL_PATH)
            { 
                m_DLLData = (asset as TextAsset).bytes;
            }
            else if(path == PDB_PATH)
            { 
                m_PDBData = (asset as TextAsset).bytes;
            }

            OnLoadFinish();
        }
         

        private void OnLoadFinish()
        {

            if (null == m_DLLData || 0 == m_DLLData.Length)
                return;
            
            if (null == m_PDBData || 0 == m_PDBData.Length)
                return;
 
            m_ScriptInterpreter.Init(m_DLLData, m_PDBData);
            m_DLLData = null;
            m_PDBData = null;

            if (null == m_LoadDllData || null == m_LoadDllData.OnSuccess)
                return;
          
            m_LoadDllData.OnSuccess();

            m_LoadDllData = null;
        }
 

    }
}
