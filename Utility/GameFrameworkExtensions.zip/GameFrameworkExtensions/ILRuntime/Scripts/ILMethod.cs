using System;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.CLR.Method;
namespace UnityGameFrameworkExtend.IL
{
    public class ILInstance : IScriptInstance
    {
        public readonly ILRuntime.Runtime.Enviorment.AppDomain m_AppDomain;
        public readonly ILTypeInstance m_Instance;
        public ILInstance(ILRuntime.Runtime.Enviorment.AppDomain appDomain,string typeName)
        {
            m_AppDomain = appDomain;
            m_Instance = m_AppDomain.Instantiate(typeName);
        }
  
        public override IInstanceMethod CreateMethod(string methodName)
        { 
            return new ILInstanceMethod(this, methodName);
        }
    }

    public class ILInstanceMethod : IInstanceMethod
    {
        private readonly ILRuntime.Runtime.Enviorment.AppDomain m_AppDomain;
        private readonly ILTypeInstance m_Instance;
        private readonly IMethod method;
        private readonly object[] param;

        public ILInstanceMethod(ILInstance instance, string methodName)
        { 
            m_AppDomain = instance.m_AppDomain;
            m_Instance = instance.m_Instance;
            this.method = this.m_Instance.Type.GetMethod(methodName);
            int n = this.method.ParameterCount;
            this.param = new object[n];
        }

        public override void Run()
        {
            this.m_AppDomain.Invoke(this.method, this.m_Instance, param);
        }

        public override void Run(object a)
        {
            this.param[0] = a;
            this.m_AppDomain.Invoke(this.method, this.m_Instance, param);
        }

        public override void Run(object a, object b)
        {
            this.param[0] = a;
            this.param[1] = b;
            this.m_AppDomain.Invoke(this.method, this.m_Instance, param);
        }

        public override void Run(object a, object b, object c)
        {
            this.param[0] = a;
            this.param[1] = b;
            this.param[2] = c;
            this.m_AppDomain.Invoke(this.method, this.m_Instance, param);
        }
    }

    public class ILStaticMethod : IStaticMethod
    {
        private readonly ILRuntime.Runtime.Enviorment.AppDomain m_AppDomain;
        private readonly IMethod method;
        private readonly object[] param;

        public ILStaticMethod(ILRuntime.Runtime.Enviorment.AppDomain appDomain,string typeName, string methodName, int paramsCount)
        {
            m_AppDomain = appDomain;
            this.method = m_AppDomain.GetType(typeName).GetMethod(methodName, paramsCount);
            this.param = new object[paramsCount];
        }

        public override void Run()
        {
            this.m_AppDomain.Invoke(this.method, null, this.param);
        }

        public override void Run(object a)
        {
            this.param[0] = a;
            this.m_AppDomain.Invoke(this.method, null, param);
        }

        public override void Run(object a, object b)
        {
            this.param[0] = a;
            this.param[1] = b;
            this.m_AppDomain.Invoke(this.method, null, param);
        }

        public override void Run(object a, object b, object c)
        {
            this.param[0] = a;
            this.param[1] = b;
            this.param[2] = c;
            this.m_AppDomain.Invoke(this.method, null, param);
        }
    }

}
