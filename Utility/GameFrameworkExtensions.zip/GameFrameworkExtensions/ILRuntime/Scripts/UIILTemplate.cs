using GameFramework;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityGameFramework.Runtime;


namespace UnityGameFrameworkExtend.IL
{
    public abstract class UIILTemplate : UIFormLogic
    {
        public string m_TypeName;
        public const int GroupDepthFactor = 1000;
        public const int DepthFactor = 10;
        private const float FadeTime = 0.3f;

        private static Font s_MainFont = null;
        private Canvas m_CachedCanvas = null;
        private CanvasGroup m_CanvasGroup = null;


        private IScriptInstance m_ScriptInstance;

        public int OriginalDepth
        {
            get;
            private set;
        }

        public int Depth
        {
            get
            {
                return m_CachedCanvas.sortingOrder;
            }
        }

        public void Close()
        {
            Close(false);
        }

        public void Close(bool ignoreFade)
        {
            StopAllCoroutines();

            if (!ignoreFade)
            {
                MYGameEntry.UI.CloseUIForm(this);
            }
            else
            {
                StartCoroutine(CloseCo(FadeTime));
            }
        }

        public void PlayUISound(int uiSoundId)
        {
            // MYGameEntry.Sound.PlayUISound(uiSoundId);
        }

        public static void SetMainFont(Font mainFont)
        {
            if (mainFont == null)
            {
                Log.Error("Main font is invalid.");
                return;
            }

            s_MainFont = mainFont;
            CheckFont();
            GameObject go = new GameObject();
            go.AddComponent<Text>().font = mainFont;
            Destroy(go);
        }

        protected internal override void OnInit(object userData)
        {
            base.OnInit(userData); 

            m_CachedCanvas = gameObject.GetOrAddComponent<Canvas>();
            m_CachedCanvas.overrideSorting = true;
            OriginalDepth = m_CachedCanvas.sortingOrder;

            m_CanvasGroup = gameObject.GetOrAddComponent<CanvasGroup>();

            RectTransform transform = GetComponent<RectTransform>();

            transform.anchorMin = Vector2.zero;
            transform.anchorMax = Vector2.one;
            transform.anchoredPosition = Vector2.zero;
            transform.sizeDelta = Vector2.zero;

            gameObject.GetOrAddComponent<GraphicRaycaster>();

 
             
            m_ScriptInstance = GameEntry.GetComponent<ILComponent>().ScriptInterpreter.CreateScriptInstance(m_TypeName);

            if (null != m_ScriptInstance)
            {
                var method = m_ScriptInstance.CreateMethod("OnInit");
                if (null != method)
                {
                    method.Run(this.gameObject,userData);
                }
            }
          
 
            InitLocalzation(this.gameObject);
        }

        public static void InitLocalzation(GameObject obj)
        {
            Text[] texts = obj.GetComponentsInChildren<Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                if (null != s_MainFont)
                    texts[i].font = s_MainFont;
                if (!string.IsNullOrEmpty(texts[i].text) && !IsNumeric(texts[i].text))
                {
                    texts[i].text = MYGameEntry.Localization.GetString(texts[i].text);
                }
            }
        }

        public static bool IsNumeric(string value)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(value, @"^[+-]?\d*[.]?\d*$");
        }


        private static void CheckFont()
        {
            //if( null == s_MainFont)
            //    s_MainFont = Font.CreateDynamicFontFromOSFont("Arial",26);

        }

        protected internal override void OnOpen(object userData)
        {
            base.OnOpen(userData);

            if (null != m_ScriptInstance)
            {
                var method = m_ScriptInstance.CreateMethod("OnOpen");
                if (null != method)
                {
                    method.Run(userData);
                }
            }
            m_CanvasGroup.alpha = 0f;
            StopAllCoroutines();
            StartCoroutine(m_CanvasGroup.FadeToAlpha(1f, FadeTime));
        }

        protected internal override void OnClose(object userData)
        {
            if (null != m_ScriptInstance)
            {
                var method = m_ScriptInstance.CreateMethod("OnClose");
                if (null != method)
                {
                    method.Run(userData);
                }
            }
            base.OnClose(userData);
        }

        protected internal override void OnPause()
        {
            base.OnPause();
        }

        protected internal override void OnResume()
        {
            base.OnResume();

            m_CanvasGroup.alpha = 0f;
            StopAllCoroutines();
            StartCoroutine(m_CanvasGroup.FadeToAlpha(1f, FadeTime));
        }

        protected internal override void OnCover()
        {
            base.OnCover();
        }

        protected internal override void OnReveal()
        {
            base.OnReveal();
        }

        protected internal override void OnRefocus(object userData)
        {
            base.OnRefocus(userData);
        }

        protected internal override void OnUpdate(float elapseSeconds, float realElapseSeconds)
        {
            base.OnUpdate(elapseSeconds, realElapseSeconds);

            if (null != m_ScriptInstance)
            {
                var method = m_ScriptInstance.CreateMethod("OnUpdate");
                if (null != method)
                {
                    method.Run(this.gameObject, elapseSeconds,realElapseSeconds);
                }
            }
        }

        protected internal override void OnDepthChanged(int uiGroupDepth, int depthInUIGroup)
        {
            int oldDepth = Depth;
            base.OnDepthChanged(uiGroupDepth, depthInUIGroup);
            int deltaDepth = GroupDepthFactor * uiGroupDepth + DepthFactor * depthInUIGroup - oldDepth + OriginalDepth;

            Canvas[] canvases = GetComponentsInChildren<Canvas>(true);
            for (int i = 0; i < canvases.Length; i++)
            {
                canvases[i].sortingOrder += deltaDepth;
            }
        }

        private IEnumerator CloseCo(float duration)
        {
            yield return m_CanvasGroup.FadeToAlpha(0f, duration);
            MYGameEntry.UI.CloseUIForm(this);
        }

    }
}
