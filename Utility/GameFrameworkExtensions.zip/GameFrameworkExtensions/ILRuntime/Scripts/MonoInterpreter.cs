using System;
using System.Reflection;
namespace UnityGameFrameworkExtend.IL
{
    public class MonoInterpreter : IScriptInterpreter
    {
        private Assembly m_Assembly;

        public void Init(byte[] asset, byte[] pdb)
        {
            m_Assembly = Assembly.Load(asset, pdb);
        }
 
        public IStaticMethod CreateStaticMethod(string className, string methodName)
        { 
            return new MonoStaticMethod(m_Assembly , className, methodName);

        }
        public IScriptInstance CreateScriptInstance(string className)
        {
            return new MonoInstance( m_Assembly , className); 
        }
 
    }
}
