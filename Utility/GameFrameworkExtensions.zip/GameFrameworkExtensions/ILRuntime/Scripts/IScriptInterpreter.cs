namespace UnityGameFrameworkExtend.IL
{
    public interface IScriptInterpreter
    {
        void Init(byte[] asset, byte[] pdb);
        IStaticMethod CreateStaticMethod(string className,string methodName); 
        IScriptInstance CreateScriptInstance(string className);
    }
}
