using System.IO;

namespace UnityGameFrameworkExtend.IL
{
    public class ILInterpreter : IScriptInterpreter
    {

        ILRuntime.Runtime.Enviorment.AppDomain m_AppDomain;

        public void Init(byte[] asset, byte[] pdb)
        {

            using (MemoryStream fs = new MemoryStream(asset))
            {
                using (MemoryStream p = new MemoryStream(pdb))
                {
                    m_AppDomain.LoadAssembly(fs, p, new Mono.Cecil.Pdb.PdbReaderProvider());
                }
            }
        }

        public IStaticMethod CreateStaticMethod(string className, string methodName)
        {
            return  new ILStaticMethod(m_AppDomain , className, methodName, 0);

        }
   
 
        public IScriptInstance CreateScriptInstance(string className)
        {
            return new ILInstance(m_AppDomain, className);
        }

    }
}
