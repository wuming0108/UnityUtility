using System;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: System.Reflection.AssemblyVersion("1.0.5606.24132")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCopyright("John")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyTitle("DPhysics_Core")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows = true)]
